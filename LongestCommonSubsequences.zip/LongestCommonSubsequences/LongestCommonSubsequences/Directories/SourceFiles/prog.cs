using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ProgrammingTask
{
    class Program1
    {
        static void Main1(string[] args)
        {
            Console.WriteLine("Hello World");
        }

        

        public void ReadFiles()
        {
            string folderPath = "H:\\SoftwareProductLines\\UofA\\Tasks\\Tokenization";

            foreach (string file in Directory.EnumerateFiles(folderPath, "*.xml"))
            {
                string contents = File.ReadAllText(file);

            }//end foreach

        }//end method


    }
}
